package com.mobastream.studio

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ScreenRecordService : Service() {
    override fun onCreate(){ super.onCreate(); createChannel(); if(Build.VERSION.SDK_INT>=29) startForeground(10, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(10,notification()) }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { val data=intent?.getParcelableExtra<Intent>("resultData"); if(data!=null){ val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; mgr.getMediaProjection(Activity.RESULT_OK,data) }; return START_NOT_STICKY }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("record","MobaStream Recording",NotificationManager.IMPORTANCE_LOW))} }
    private fun notification()=NotificationCompat.Builder(this,"record").setContentTitle("MobaStream Studio").setContentText("Gravação em andamento").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    override fun onBind(intent:Intent?):IBinder?=null
}
