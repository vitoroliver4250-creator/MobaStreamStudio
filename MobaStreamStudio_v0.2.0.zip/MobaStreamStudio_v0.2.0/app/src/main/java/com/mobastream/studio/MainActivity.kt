package com.mobastream.studio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF08070D); private val Card = Color(0xFF15121E); private val Neon = Color(0xFF9C4DFF)

class MainActivity : ComponentActivity() {
    private var projectionResult by mutableStateOf<Intent?>(null)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { StudioApp() } }

    @Composable fun StudioApp() {
        var selected by remember { mutableStateOf(0) }; var recording by remember { mutableStateOf(false) }
        val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
        val projection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) { projectionResult = r.data; startRecorder(r.data!!); recording = true }
        }
        fun start() {
            permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection.launch(mgr.createScreenCaptureIntent())
        }
        MaterialTheme(colorScheme = darkColorScheme(background=Bg, surface=Card, primary=Neon)) {
            Scaffold(containerColor=Bg, bottomBar={ NavigationBar(containerColor=Card) {
                listOf("Início","Gravar","Live","Galeria","Config.").forEachIndexed { i, label -> NavigationBarItem(selected=i==selected,onClick={selected=i},icon={Icon(if(i==0) Icons.Default.Home else if(i==1) Icons.Default.Videocam else if(i==2) Icons.Default.Wifi else if(i==3) Icons.Default.VideoLibrary else Icons.Default.Settings,label)},label={Text(label)}) }
            }}) { pad -> Box(Modifier.fillMaxSize().padding(pad)) { when(selected) { 0 -> Home(recording){start()}; 1 -> RecordPage(recording,onStart={start()},onStop={ stopRecorder(); recording=false }); 2 -> LivePage(); 3 -> GalleryPage(); else -> SettingsPage() } } }
        }
    }
    private fun startRecorder(data: Intent) { ContextCompat.startForegroundService(this, Intent(this, ScreenRecordService::class.java).apply { putExtra("resultData", data) }) }
    private fun stopRecorder() { stopService(Intent(this, ScreenRecordService::class.java)) }
}

@Composable fun Home(recording:Boolean,onRecord:()->Unit) { Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) { Spacer(Modifier.height(30.dp)); Text("MOBA",style=MaterialTheme.typography.displaySmall,color=Color.White); Text("STREAM STUDIO",style=MaterialTheme.typography.headlineMedium,color=Neon); Spacer(Modifier.height(35.dp)); Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp)) { Column(Modifier.padding(24.dp)) { Text(if(recording) "GRAVAÇÃO ATIVA" else "Pronto para gravar",style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(8.dp)); Text("Gameplay • câmera frontal • microfone • áudio do dispositivo"); Spacer(Modifier.height(24.dp)); Button(onClick=onRecord,modifier=Modifier.fillMaxWidth(),enabled=!recording){Icon(Icons.Default.FiberManualRecord,null);Spacer(Modifier.width(8.dp));Text("INICIAR GRAVAÇÃO")} } }; Spacer(Modifier.height(20.dp)); Feature("CLIP / REPLAY BUFFER","Salve os últimos 30–180 segundos"); Feature("CÂMERA FLUTUANTE","Posição e tamanho ajustáveis"); Feature("EDITOR","Corte, texto, filtros e áudio") } }
@Composable fun Feature(t:String,s:String){Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CheckCircle,null,tint=Neon);Spacer(Modifier.width(12.dp));Column{Text(t);Text(s,style=MaterialTheme.typography.bodySmall,color=Color.LightGray)}}}}
@Composable fun RecordPage(recording:Boolean,onStart:()->Unit,onStop:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Text("GRAVAR",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(20.dp));SettingRow("Qualidade","1080P • 60 FPS");SettingRow("Microfone", "Ativado");SettingRow("Áudio do dispositivo","Ativado");SettingRow("Câmera frontal","Pronta");Spacer(Modifier.weight(1f));Button(onClick=if(recording) onStop else onStart,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(recording) Color(0xFFB00020) else Neon)){Text(if(recording)"PARAR GRAVAÇÃO" else "INICIAR GRAVAÇÃO")}}}
@Composable fun SettingRow(a:String,b:String){Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(Modifier.padding(16.dp),Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(a);Text(b,color=Neon)}}}
@Composable fun LivePage(){EmptyPage("LIVE STREAM","YouTube / Facebook / Instagram via integrações oficiais")}
@Composable fun GalleryPage(){EmptyPage("GALERIA","Seus vídeos, clips e transmissões")}
@Composable fun SettingsPage(){EmptyPage("CONFIGURAÇÕES","FPS • resolução • armazenamento • notificações • preferências")}
@Composable fun EmptyPage(t:String,s:String){Column(Modifier.fillMaxSize().padding(20.dp)){Text(t,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text(s,color=Color.LightGray)}}
