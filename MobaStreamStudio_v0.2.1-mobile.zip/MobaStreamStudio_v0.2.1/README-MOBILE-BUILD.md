# MobaStream Studio v0.2.1 — preparado para compilação pelo celular

Esta versão foi ajustada para que o APK possa ser compilado sem Android Studio no telefone.

## Método recomendado: GitHub Actions

O projeto já traz um workflow em `.github/workflows/build-apk.yml`.

1. Envie esta pasta para um repositório GitHub.
2. Pelo navegador do celular, abra **Actions**.
3. Execute **Build MobaStream Studio APK**.
4. Aguarde a compilação.
5. Abra a execução concluída e baixe o artefato `MobaStreamStudio-v0.2.1-debug`.
6. Extraia o APK e instale no telefone para teste.

O workflow configura Java 17 e Gradle 8.11.1 no servidor de build. Assim, o telefone só precisa do navegador e de uma conta GitHub; Android Studio não é necessário.

## O que foi ajustado no v0.2.1
- versão do app: 0.2.1 / versionCode 3;
- build otimizado para ambiente de CI/cloud;
- memória do Gradle reduzida para 1536 MB;
- daemon desativado no projeto, adequado para builds pontuais;
- Java/Kotlin configurados para JVM 17;
- build release sem minificação, facilitando o primeiro APK de teste;
- workflow automático para gerar `app-debug.apk`;
- dependências e AndroidX mantidos compatíveis com a base existente.

## Observação
O APK de teste é uma build de desenvolvimento. Os recursos de gravação, câmera, editor, replay buffer e integrações de live ainda precisam ser implementados/validados por etapas no aplicativo; esta versão prioriza deixar o projeto compilável e fácil de testar pelo celular.
